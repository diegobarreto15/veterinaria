﻿Public Class logicaMascota
    Public Sub altaMascota(mascota As mascota)
        Dim persistencia As New persistenciaMascota
        persistencia.AltaMascota(mascota)
    End Sub
    Public Function listarMascota(ci As Integer) As List(Of mascota)
        Dim pesistencia As New persistenciaMascota
        Return pesistencia.listarMascota(ci)
    End Function
    Public Sub modificarMascota(mascota As mascota)
        Dim persistencia As New persistenciaMascota
        persistencia.modificarMascota(mascota)
    End Sub
    Public Function buscarMascota(id As Integer) As mascota
        Dim persistencias As New persistenciaMascota
        Return persistencias.buscarMascota(id)
    End Function
    Public Sub bajaMascotas(ci As Integer)
        Dim persistencia As New persistenciaMascota
        persistencia.bajaMascotas(ci)
    End Sub
    Public Sub borrarMascota(id As Integer)
        Dim persistencias As New persistenciaMascota
        persistencias.borrarMascota(id)
    End Sub

End Class
