﻿Public Class Inicio
    Private Sub AltaPersonaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AltaPersonaToolStripMenuItem.Click
        CrearPersonas.Show()
    End Sub

    Private Sub AltaMascotasToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AltaMascotasToolStripMenuItem.Click
        Mascotas.Show()
    End Sub
End Class
