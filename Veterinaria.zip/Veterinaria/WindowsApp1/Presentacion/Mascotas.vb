﻿Public Class Mascotas
    Dim Nombre As String
    Dim CiDueño As Integer
    Dim FechaNac As Integer



    Private Sub btnCrearMasc_Click(sender As Object, e As EventArgs) Handles btnCrearMasc.Click
        Nombre = tbxNombreMasc.Text
        CiDueño = tbxIdMascota.Text
        FechaNac = tbxAñoNac.Text

        Dim newMascota As New mascota
        Dim newlogicaPersona As New logicaPersona
        newMascota.Dueno = newlogicaPersona.buscarPersona(CiDueño)
        newMascota.Nombre = Nombre
        newMascota.AnoNac = FechaNac
        Dim logica As New logicaMascota()
        logica.altaMascota(newMascota)



    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim newmascota As New mascota()
        Dim logica As New logicaMascota
        Dim logicaPersona As New logicaPersona
        If tbxIdMascota.Text = "" Then

        Else

            newmascota = logica.buscarMascota(Convert.ToInt32(tbxIdMascota.Text))

            Me.tbxNombreMasc.Text = newmascota.Nombre
            Me.tbxAñoNac.Text = newmascota.AnoNac
            Me.tbxIdMascota.Enabled = False
            newmascota.Dueno = logicaPersona.buscarPersona(tbxIdMascota.Text)
            Me.tbxIdMascota.Text = newmascota.Dueno.CedulaProp.ToString
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim logica As New logicaMascota

        Dim newmascota As New mascota
        newmascota.Nombre = tbxNombreMasc.Text
        newmascota.AnoNac = Convert.ToInt32(tbxAñoNac.Text)
        newmascota.Id = logica.buscarMascota(Convert.ToInt32(tbxIdMascota.Text)).Id
        logica.modificarMascota(newmascota)
    End Sub
End Class