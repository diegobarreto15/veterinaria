﻿Public Class listarPersonas

    Dim conection = New Npgsql.NpgsqlConnection


    Private Sub listarPersonas_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim cedula As ListViewItem
        Dim listaPersona As List(Of persona)
        Dim logica As New logicaPersona


        If (listaPersona.Count > 0) Then
            For index As Integer = 0 To listaPersona.Count

                'cedula.SubItems.Add(listaPersona.IndexOf)

            Next
        End If


    End Sub
End Class