﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Mascotas
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCrearMasc = New System.Windows.Forms.Button()
        Me.tbxAñoNac = New System.Windows.Forms.TextBox()
        Me.tbxNombreMasc = New System.Windows.Forms.TextBox()
        Me.lblFechaNacMasc = New System.Windows.Forms.Label()
        Me.lblNombreMasc = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.tbxIdMascota = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnCrearMasc
        '
        Me.btnCrearMasc.Location = New System.Drawing.Point(538, 225)
        Me.btnCrearMasc.Name = "btnCrearMasc"
        Me.btnCrearMasc.Size = New System.Drawing.Size(105, 23)
        Me.btnCrearMasc.TabIndex = 19
        Me.btnCrearMasc.Text = "Crear mascota"
        Me.btnCrearMasc.UseVisualStyleBackColor = True
        '
        'tbxAñoNac
        '
        Me.tbxAñoNac.Location = New System.Drawing.Point(381, 131)
        Me.tbxAñoNac.Name = "tbxAñoNac"
        Me.tbxAñoNac.Size = New System.Drawing.Size(114, 20)
        Me.tbxAñoNac.TabIndex = 18
        '
        'tbxNombreMasc
        '
        Me.tbxNombreMasc.Location = New System.Drawing.Point(381, 57)
        Me.tbxNombreMasc.Name = "tbxNombreMasc"
        Me.tbxNombreMasc.Size = New System.Drawing.Size(114, 20)
        Me.tbxNombreMasc.TabIndex = 15
        '
        'lblFechaNacMasc
        '
        Me.lblFechaNacMasc.AutoSize = True
        Me.lblFechaNacMasc.Font = New System.Drawing.Font("Segoe UI Emoji", 8.25!)
        Me.lblFechaNacMasc.Location = New System.Drawing.Point(271, 131)
        Me.lblFechaNacMasc.Name = "lblFechaNacMasc"
        Me.lblFechaNacMasc.Size = New System.Drawing.Size(104, 15)
        Me.lblFechaNacMasc.TabIndex = 12
        Me.lblFechaNacMasc.Text = "Año de nacimiento"
        '
        'lblNombreMasc
        '
        Me.lblNombreMasc.AutoSize = True
        Me.lblNombreMasc.Font = New System.Drawing.Font("Segoe UI Emoji", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombreMasc.Location = New System.Drawing.Point(296, 60)
        Me.lblNombreMasc.Name = "lblNombreMasc"
        Me.lblNombreMasc.Size = New System.Drawing.Size(51, 15)
        Me.lblNombreMasc.TabIndex = 11
        Me.lblNombreMasc.Text = "Nombre:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(322, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(138, 25)
        Me.Label1.TabIndex = 10
        Me.Label1.Text = "MASCOTAS"
        '
        'tbxIdMascota
        '
        Me.tbxIdMascota.Location = New System.Drawing.Point(381, 93)
        Me.tbxIdMascota.Name = "tbxIdMascota"
        Me.tbxIdMascota.Size = New System.Drawing.Size(114, 20)
        Me.tbxIdMascota.TabIndex = 21
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI Emoji", 8.25!)
        Me.Label2.Location = New System.Drawing.Point(271, 93)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(79, 15)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "ID de mascota"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(538, 55)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(105, 23)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Buscar mascota"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(390, 225)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(105, 23)
        Me.Button2.TabIndex = 24
        Me.Button2.Text = "Modificar mascota"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(242, 225)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(105, 23)
        Me.Button3.TabIndex = 25
        Me.Button3.Text = "Cancelar"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Mascotas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.tbxIdMascota)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnCrearMasc)
        Me.Controls.Add(Me.tbxAñoNac)
        Me.Controls.Add(Me.tbxNombreMasc)
        Me.Controls.Add(Me.lblFechaNacMasc)
        Me.Controls.Add(Me.lblNombreMasc)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Mascotas"
        Me.Text = "Mascotas"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCrearMasc As Button
    Friend WithEvents tbxAñoNac As TextBox
    Friend WithEvents tbxNombreMasc As TextBox
    Friend WithEvents lblFechaNacMasc As Label
    Friend WithEvents lblNombreMasc As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents tbxIdMascota As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
End Class
